package app;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

@Path("/profile")
public class ProfileService {

	@POST
	@Path("/create")
	public String createProfile(@QueryParam("username") String username, UserProfile profile) {

		Person p = PersonDAO.findPersonByUsername(username);

		profile.setPerson(p);
		ProfileDAO.createProfile(profile);

		System.out.println(username + ",  user profile");

		return "Success";
	}

	@GET
	@Path("/getProfileByUsername")
	@Produces(MediaType.APPLICATION_JSON)
	public UserProfile getProfileByUsername(@QueryParam("username") String username) {

		Integer id = PersonDAO.findPersonByUsername(username).getId();

		UserProfile profile = ProfileDAO.findProfileById(id);

		return profile;

	}

	// getProfileByUsername
	// getProfileByActiveUser
	// updateProfile
	// getAllProfiles

}
