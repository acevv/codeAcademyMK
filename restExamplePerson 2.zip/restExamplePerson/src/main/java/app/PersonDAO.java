package app;

import java.io.File;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

public class PersonDAO {

	static Transaction tx = null;

	public static Session initDB() {

		String hibernatePropsFilePath = "/Users/acev/Downloads/restUserComplete/restExamplePerson/src/main/resources/hibernate.cfg.xml";
		File hibernatePropsFile = new File(hibernatePropsFilePath);

		Configuration cfg = new Configuration();

		cfg.configure(hibernatePropsFile);

		cfg.addAnnotatedClass(app.Person.class);
		cfg.addAnnotatedClass(app.UserProfile.class);

		StandardServiceRegistryBuilder serviceRegistryBuilder = new StandardServiceRegistryBuilder()
				.applySettings(cfg.getProperties());

		ServiceRegistry serviceRegistry = serviceRegistryBuilder.build();

		SessionFactory sessionFactory = cfg.buildSessionFactory(serviceRegistry);

//		factory = cfg.configure().buildSessionFactory();
		Session session = sessionFactory.openSession();

		return session;
	}

	public static String insertpersonInDB(Person person) {

		try {

			Session s = initDB();
			tx = s.beginTransaction();

			s.save(person);

			tx.commit();

			s.close();
			return "Person with id: " + person.getId() + "has been created";

		} catch (HibernateException e) {
			tx.rollback();
			System.out.println(e);

		}
		return null;
	}

	public static List<Person> getAllFromDB() {
		List<Person> result = new ArrayList<Person>();

		try {
			Session s = initDB();
			tx = s.beginTransaction();

			result = s.createQuery("SELECT p FROM Person AS p").list();

			tx.commit();
			s.close();
		} catch (HibernateException e) {
			e.printStackTrace();
			tx.rollback();
		}

		return result;
	}

	public static Person findPersonByIdDB(Integer id) {
		List<Person> result = new ArrayList<Person>();

		try {
			Session s = initDB();
			tx = s.beginTransaction();

//				result = s.createQuery("SELECT p FROM Person AS p").list();
			result = s.createNativeQuery("SELECT * FROM Person WHERE id=" + id + ";", Person.class).list();

			tx.commit();
			s.close();
		} catch (HibernateException e) {
			e.printStackTrace();
			tx.rollback();
		}

		return result.get(0);
	}

	public static Person findPersonByUsernamePassword(String username, String password) {

		List<Person> result = new ArrayList<Person>();

		try {
			Session s = initDB();
			tx = s.beginTransaction();

			result = s.createNativeQuery(
					"SELECT * FROM Person WHERE username='" + username + "' AND password='" + password + "';",
					Person.class).list();

			if (result.isEmpty()) {
				return null;
			}

			tx.commit();
			s.close();

		} catch (HibernateException e) {
			tx.rollback();
			System.out.println(e);
		}

		return result.get(0);
	}

	public static void main(String[] args) {
		initDB();
	}

	public static String updateLoginStatus(Person p) {

		Session s = initDB();

		tx = s.beginTransaction();

		p.setLoginStatus(true);

		p.setLoginTime(new Date(System.currentTimeMillis()));
		s.update(p);

		tx.commit();
		s.close();
		return "";

	}

	public static Person checkLoginStatus(String username) {

		List<Person> result = new ArrayList<Person>();

		try {
			Session s = initDB();
			tx = s.beginTransaction();

			result = s.createNativeQuery("SELECT * FROM Person WHERE username='" + username + "';", Person.class)
					.list();

			if (result.isEmpty()) {
				return null;
			}

			tx.commit();
			s.close();

		} catch (HibernateException e) {
			tx.rollback();
			System.out.println(e);
		}

		return result.get(0);
	}

	public static void changeLoginStatus(Person p) {
		Session s = initDB();

		tx = s.beginTransaction();

		p.setLoginStatus(false);

		s.update(p);

		tx.commit();
		s.close();

	}

	public static Person findPersonByUsername(String username) {

		List<Person> result = new ArrayList<Person>();

		try {
			Session s = initDB();
			tx = s.beginTransaction();

			result = s.createNativeQuery("SELECT * FROM Person WHERE username='" + username + "';", Person.class)
					.list();

			if (result.isEmpty()) {
				return null;
			}

			tx.commit();
			s.close();

		} catch (HibernateException e) {
			tx.rollback();
			System.out.println(e);
		}

		return result.get(0);
	}

}
