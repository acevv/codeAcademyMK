package app;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

public class ProfileDAO {

	static Transaction tx = null;

	public static Session initDB() {

		String hibernatePropsFilePath = "/Users/acev/Downloads/restUserComplete/restExamplePerson/src/main/resources/hibernate.cfg.xml";
		File hibernatePropsFile = new File(hibernatePropsFilePath);

		Configuration cfg = new Configuration();

		cfg.configure(hibernatePropsFile);

		cfg.addAnnotatedClass(app.Person.class);
		cfg.addAnnotatedClass(app.UserProfile.class);

		StandardServiceRegistryBuilder serviceRegistryBuilder = new StandardServiceRegistryBuilder()
				.applySettings(cfg.getProperties());

		ServiceRegistry serviceRegistry = serviceRegistryBuilder.build();

		SessionFactory sessionFactory = cfg.buildSessionFactory(serviceRegistry);

		Session session = sessionFactory.openSession();

		return session;
	}

	public static String createProfile(UserProfile profile) {

		try {

			Session s = initDB();
			tx = s.beginTransaction();

			s.save(profile);

			tx.commit();

			s.close();
			return "User profile with id: " + profile.getId() + "has been created";

		} catch (HibernateException e) {
			tx.rollback();
			System.out.println(e);

		}
		return null;
	}

	public static UserProfile findProfileById(Integer id) {

		List<UserProfile> result = new ArrayList<UserProfile>();

		try {
			Session s = initDB();
			tx = s.beginTransaction();

			result = s.createNativeQuery("SELECT * FROM user_profile WHERE personid='" + id + "';", UserProfile.class).list();

			if (result.isEmpty()) {
				return null;
			}

			tx.commit();
			s.close();

		} catch (HibernateException e) {
			tx.rollback();
			System.out.println(e);
		}

		return result.get(0);

	}

}
